class_name TerrainMap
extends Node3D
# Procedural islands. height_at() is also used for crash detection (no physics bodies needed).

const SIZE := 12000.0
const RES := 180

var noise := FastNoiseLite.new()

func _ready() -> void:
	add_to_group("terrain")
	noise.seed = 11
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.00035
	noise.fractal_octaves = 4
	_build()

func height_at(x: float, z: float) -> float:
	var n: float = noise.get_noise_2d(x, z) * 0.5 + 0.5
	var d: float = Vector2(x, z).length() / (SIZE * 0.5)
	var h: float = pow(n, 1.6) * 1300.0 - 300.0
	h -= smoothstep(0.55, 1.0, d) * 500.0
	return h

func _col(h: float) -> Color:
	if h < 4.0:
		return Color(0.78, 0.72, 0.52)
	if h < 140.0:
		return Color(0.22, 0.48, 0.2).lerp(Color(0.3, 0.45, 0.2), h / 140.0)
	if h < 380.0:
		return Color(0.34, 0.38, 0.24).lerp(Color(0.45, 0.42, 0.4), (h - 140.0) / 240.0)
	if h < 520.0:
		return Color(0.45, 0.42, 0.4)
	return Color(0.93, 0.95, 0.98)

func _build() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var step := SIZE / RES
	var half := SIZE * 0.5
	var e := step
	for j in range(RES + 1):
		for i in range(RES + 1):
			var x := -half + i * step
			var z := -half + j * step
			var h := height_at(x, z)
			var nrm := Vector3(height_at(x - e, z) - height_at(x + e, z), 2.0 * e, height_at(x, z - e) - height_at(x, z + e)).normalized()
			st.set_normal(nrm)
			st.set_color(_col(h))
			st.add_vertex(Vector3(x, h, z))
	for j in range(RES):
		for i in range(RES):
			var a := j * (RES + 1) + i
			var b := a + 1
			var c := a + RES + 1
			var d := c + 1
			st.add_index(a)
			st.add_index(b)
			st.add_index(c)
			st.add_index(b)
			st.add_index(d)
			st.add_index(c)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = mat
	add_child(mi)
