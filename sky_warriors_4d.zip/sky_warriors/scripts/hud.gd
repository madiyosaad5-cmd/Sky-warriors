class_name Hud
extends Control
# Touch controls (floating joystick, throttle slider, buttons) + HUD (radar, lock box, readouts).
# Desktop testing: WASD/QE fly, Shift/Ctrl throttle, Space gun, M missile, F flare, B brake, C camera, I invert, Esc pause.

const JOY_R := 110.0
const GREEN := Color(0.5, 1.0, 0.6)
const RED := Color(1.0, 0.3, 0.25)

var jet: Jet
var font: Font = ThemeDB.fallback_font
var joy_id := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var thr_id := -1
var held := {}

func _process(_dt: float) -> void:
	queue_redraw()

# ---------- layout ----------
func _round_buttons() -> Dictionary:
	var s := size
	return {
		"fire": [Vector2(s.x - 210.0, s.y - 130.0), 72.0],
		"msl": [Vector2(s.x - 345.0, s.y - 80.0), 48.0],
		"flare": [Vector2(s.x - 355.0, s.y - 195.0), 44.0],
		"brake": [Vector2(s.x - 215.0, s.y - 270.0), 40.0],
	}

func _rect_buttons() -> Dictionary:
	var s := size
	return {
		"cam": Rect2(s.x - 280.0, 14.0, 80.0, 44.0),
		"inv": Rect2(s.x - 190.0, 14.0, 80.0, 44.0),
		"pause": Rect2(s.x - 100.0, 14.0, 84.0, 44.0),
	}

func _slider_rect() -> Rect2:
	return Rect2(size.x - 100.0, 110.0, 90.0, size.y - 150.0)

# ---------- input ----------
func _input(e: InputEvent) -> void:
	if jet == null:
		return
	if e is InputEventScreenTouch:
		var t := e as InputEventScreenTouch
		_down(t.index, t.position, t.pressed)
	elif e is InputEventScreenDrag:
		var d := e as InputEventScreenDrag
		_move(d.index, d.position)
	elif e is InputEventMouseButton and not DisplayServer.is_touchscreen_available():
		var m := e as InputEventMouseButton
		if m.button_index == MOUSE_BUTTON_LEFT:
			_down(0, m.position, m.pressed)
	elif e is InputEventMouseMotion and not DisplayServer.is_touchscreen_available():
		var mm := e as InputEventMouseMotion
		if mm.button_mask & MOUSE_BUTTON_MASK_LEFT:
			_move(0, mm.position)
	elif e is InputEventKey:
		var k := e as InputEventKey
		if not k.pressed or k.echo:
			return
		match k.physical_keycode:
			KEY_ESCAPE, KEY_P:
				_set_paused(not get_tree().paused)
			KEY_M:
				if not get_tree().paused:
					jet.fire_missile()
			KEY_F:
				if not get_tree().paused:
					jet.drop_flare()
			KEY_C:
				if not get_tree().paused:
					jet.toggle_cam()
			KEY_I:
				jet.invert_y = not jet.invert_y

func _set_paused(v: bool) -> void:
	if v:
		jet.fire_held = false
		jet.brake = false
		jet.stick = Vector2.ZERO
		joy_id = -1
		thr_id = -1
		held.clear()
	get_tree().paused = v

func _down(idx: int, p: Vector2, pressed: bool) -> void:
	if not pressed:
		if idx == joy_id:
			joy_id = -1
			jet.stick = Vector2.ZERO
		if idx == thr_id:
			thr_id = -1
		if held.has(idx):
			_release(held[idx])
			held.erase(idx)
		return
	if get_tree().paused:
		var c := size * 0.5
		if Rect2(c.x - 130.0, c.y - 60.0, 260.0, 60.0).has_point(p):
			_set_paused(false)
		elif Rect2(c.x - 130.0, c.y + 20.0, 260.0, 60.0).has_point(p):
			get_tree().quit()
		return
	var rb := _round_buttons()
	for id in rb:
		var v: Array = rb[id]
		var bc: Vector2 = v[0]
		var br: float = v[1]
		if p.distance_to(bc) <= br + 10.0:
			held[idx] = id
			_press(id)
			return
	var rr := _rect_buttons()
	for id in rr:
		var r: Rect2 = rr[id]
		if r.has_point(p):
			_press(id)
			return
	if _slider_rect().has_point(p):
		thr_id = idx
		_set_thr(p)
		return
	if p.x < size.x * 0.55 and joy_id == -1:
		joy_id = idx
		joy_origin = p
		joy_pos = p

func _move(idx: int, p: Vector2) -> void:
	if idx == joy_id:
		var v := (p - joy_origin).limit_length(JOY_R)
		joy_pos = joy_origin + v
		var n := v / JOY_R
		if n.length() > 0.08:
			jet.stick = n.normalized() * pow(n.length(), 1.3)
		else:
			jet.stick = Vector2.ZERO
	elif idx == thr_id:
		_set_thr(p)

func _set_thr(p: Vector2) -> void:
	var r := _slider_rect()
	jet.throttle = clampf(1.0 - (p.y - r.position.y) / r.size.y, 0.0, 1.0)

func _press(id: String) -> void:
	match id:
		"fire":
			jet.fire_held = true
		"brake":
			jet.brake = true
		"msl":
			jet.fire_missile()
		"flare":
			jet.drop_flare()
		"cam":
			jet.toggle_cam()
		"inv":
			jet.invert_y = not jet.invert_y
		"pause":
			_set_paused(true)

func _release(id: String) -> void:
	match id:
		"fire":
			jet.fire_held = false
		"brake":
			jet.brake = false

# ---------- drawing ----------
func _txt(t: String, p: Vector2, sz: int = 22, col: Color = GREEN, w: float = -1.0, al: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	draw_string(font, p, t, al, w, sz, col)

func _draw() -> void:
	if jet == null:
		return
	_draw_controls()
	_draw_hud()
	if get_tree().paused:
		_draw_pause()

func _draw_controls() -> void:
	var base := joy_origin if joy_id != -1 else Vector2(170.0, size.y - 150.0)
	var knob := joy_pos if joy_id != -1 else base
	draw_arc(base, JOY_R, 0.0, TAU, 40, Color(GREEN, 0.5), 3.0)
	draw_circle(knob, 40.0, Color(GREEN, 0.35))
	var act := held.values()
	var rb := _round_buttons()
	for id in rb:
		var v: Array = rb[id]
		var bc: Vector2 = v[0]
		var br: float = v[1]
		var col := RED if id == "fire" else GREEN
		draw_circle(bc, br, Color(col, 0.35 if act.has(id) else 0.15))
		draw_arc(bc, br, 0.0, TAU, 32, Color(col, 0.8), 3.0)
		_txt(String(id).to_upper(), bc + Vector2(-br, 8.0), 20, col, br * 2.0, HORIZONTAL_ALIGNMENT_CENTER)
	var rr := _rect_buttons()
	for id in rr:
		var r: Rect2 = rr[id]
		var on := id == "inv" and jet.invert_y
		draw_rect(r, Color(GREEN, 0.35 if on else 0.15))
		draw_rect(r, Color(GREEN, 0.8), false, 2.0)
		var label := "INV Y" if id == "inv" else String(id).to_upper()
		_txt(label, Vector2(r.position.x, r.position.y + 29.0), 18, GREEN, r.size.x, HORIZONTAL_ALIGNMENT_CENTER)
	var sr := _slider_rect()
	var x := size.x - 55.0
	var ky := sr.end.y - jet.throttle * sr.size.y
	draw_line(Vector2(x, sr.position.y), Vector2(x, sr.end.y), Color(GREEN, 0.4), 6.0)
	draw_line(Vector2(x, sr.end.y), Vector2(x, ky), GREEN, 6.0)
	draw_circle(Vector2(x, ky), 22.0, Color(GREEN, 0.5))
	_txt("THR", Vector2(x - 50.0, sr.position.y - 12.0), 18, GREEN, 100.0, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_hud() -> void:
	var cam := jet.current_cam()
	# radar
	var rc := Vector2(110.0, 120.0)
	var rad := 85.0
	draw_circle(rc, rad, Color(0, 0.15, 0.05, 0.45))
	draw_arc(rc, rad, 0.0, TAU, 40, GREEN, 2.0)
	draw_arc(rc, rad * 0.5, 0.0, TAU, 32, Color(GREEN, 0.3), 1.0)
	draw_line(rc - Vector2(rad, 0), rc + Vector2(rad, 0), Color(GREEN, 0.2), 1.0)
	draw_line(rc - Vector2(0, rad), rc + Vector2(0, rad), Color(GREEN, 0.2), 1.0)
	draw_colored_polygon(PackedVector2Array([rc + Vector2(0, -9), rc + Vector2(-6, 7), rc + Vector2(6, 7)]), GREEN)
	var inv := jet.global_transform.basis.inverse()
	for n in get_tree().get_nodes_in_group("targets"):
		var t := n as Drone
		if t == null or not t.alive:
			continue
		var l := inv * (t.global_position - jet.global_position)
		var rp := Vector2(l.x, l.z) / 3500.0 * rad
		if rp.length() > rad - 4.0:
			rp = rp.normalized() * (rad - 4.0)
		draw_circle(rc + rp, 4.0, RED)
	# readouts
	var y := 250.0
	for line in [
		"SPD  %d km/h" % int(jet.speed * 3.6),
		"ALT  %d m" % int(jet.global_position.y),
		"THR  %d%%" % int(jet.throttle * 100.0),
		"GUN  %d" % int(jet.ammo_gun),
		"MSL  %d" % jet.ammo_missile,
		"FLR  %d" % jet.flares,
		"KILLS  %d" % jet.kills,
	]:
		_txt(line, Vector2(24.0, y), 22)
		y += 28.0
	# gun crosshair
	var aim := jet.global_position - jet.global_transform.basis.z * 800.0
	if not cam.is_position_behind(aim):
		var ap := cam.unproject_position(aim)
		draw_arc(ap, 16.0, 0.0, TAU, 24, Color(GREEN, 0.9), 2.0)
		draw_circle(ap, 2.5, GREEN)
	# lock box
	var lt := jet.lock_target
	if jet.alive and lt != null and not cam.is_position_behind(lt.global_position):
		var tp := cam.unproject_position(lt.global_position)
		var col := RED if jet.locked else Color(1.0, 0.9, 0.2)
		draw_rect(Rect2(tp - Vector2(34, 34), Vector2(68, 68)), col, false, 3.0)
		if not jet.locked:
			draw_arc(tp, 44.0, -PI / 2.0, -PI / 2.0 + TAU * minf(jet.lock_time, 1.0), 32, col, 4.0)
		_txt("%d m" % int(jet.global_position.distance_to(lt.global_position)), tp + Vector2(-40.0, 62.0), 18, col, 80.0, HORIZONTAL_ALIGNMENT_CENTER)
	if jet.locked and jet.alive:
		_txt("LOCKED - FIRE MISSILE", Vector2(0.0, 90.0), 26, RED, size.x, HORIZONTAL_ALIGNMENT_CENTER)
	# warnings
	var warn := ""
	if not jet.alive:
		warn = "AIRCRAFT DESTROYED - RESPAWNING"
	elif jet.agl < 200.0:
		warn = "PULL UP!"
	elif jet.speed < Jet.STALL:
		warn = "STALL"
	elif jet.out_of_bounds:
		warn = "LEAVING COMBAT AREA - TURNING BACK"
	if warn != "" and (Time.get_ticks_msec() / 250) % 2 == 0:
		_txt(warn, Vector2(0.0, size.y * 0.3), 38, RED, size.x, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_pause() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.6))
	var c := size * 0.5
	_txt("PAUSED", Vector2(0.0, c.y - 100.0), 44, GREEN, size.x, HORIZONTAL_ALIGNMENT_CENTER)
	var r1 := Rect2(c.x - 130.0, c.y - 60.0, 260.0, 60.0)
	var r2 := Rect2(c.x - 130.0, c.y + 20.0, 260.0, 60.0)
	for pair in [[r1, "RESUME"], [r2, "QUIT"]]:
		var r: Rect2 = pair[0]
		draw_rect(r, Color(GREEN, 0.2))
		draw_rect(r, GREEN, false, 2.0)
		_txt(pair[1], Vector2(r.position.x, r.position.y + 40.0), 26, GREEN, r.size.x, HORIZONTAL_ALIGNMENT_CENTER)
