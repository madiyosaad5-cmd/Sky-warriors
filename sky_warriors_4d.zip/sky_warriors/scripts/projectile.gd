class_name Projectile
extends Node3D
# kind: "bullet" | "missile" | "flare". Set kind/vel/target BEFORE add_child.

var kind := "bullet"
var vel := Vector3.ZERO
var target: Node3D
var life := 1.3
var terrain: TerrainMap

func _ready() -> void:
	terrain = get_tree().get_first_node_in_group("terrain") as TerrainMap
	var mi := MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	match kind:
		"bullet":
			var b := BoxMesh.new()
			b.size = Vector3(0.25, 0.25, 6.0)
			mi.mesh = b
			mat.albedo_color = Color(1.0, 0.9, 0.3)
		"missile":
			life = 7.0
			var c := CapsuleMesh.new()
			c.radius = 0.3
			c.height = 4.0
			mi.mesh = c
			mi.rotation_degrees.x = 90.0
			mat.albedo_color = Color(0.9, 0.9, 0.95)
			_add_trail()
		"flare":
			life = 6.0
			var s := SphereMesh.new()
			s.radius = 1.0
			s.height = 2.0
			s.radial_segments = 8
			s.rings = 4
			mi.mesh = s
			mat.albedo_color = Color(1.0, 0.6, 0.15)
	mi.material_override = mat
	add_child(mi)
	if vel.length() > 0.1:
		var d := vel.normalized()
		look_at(global_position + d, Vector3.UP if absf(d.y) < 0.98 else Vector3.RIGHT)

func _add_trail() -> void:
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 6
	sm.rings = 3
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.vertex_color_use_as_albedo = true
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.8))
	g.set_color(1, Color(0.7, 0.7, 0.7, 0.0))
	var p := CPUParticles3D.new()
	p.amount = 100
	p.lifetime = 1.5
	p.local_coords = false
	p.mesh = sm
	p.material_override = mat
	p.color_ramp = g
	p.direction = Vector3(0, 0, 1)
	p.spread = 4.0
	p.initial_velocity_min = 0.0
	p.initial_velocity_max = 2.0
	p.gravity = Vector3.ZERO
	p.scale_amount_min = 1.2
	p.scale_amount_max = 2.4
	p.position = Vector3(0, 0, 2.2)
	add_child(p)

func _process(dt: float) -> void:
	life -= dt
	if life <= 0.0:
		if kind == "missile":
			Fx.explode(get_tree(), global_position, 14.0)
		queue_free()
		return
	if kind == "flare":
		vel.y -= 25.0 * dt
		vel *= (1.0 - 0.6 * dt)
	elif kind == "missile":
		_home(dt)
	var prev := global_position
	var nxt := prev + vel * dt
	global_position = nxt
	if kind == "flare":
		return
	for n in get_tree().get_nodes_in_group("targets"):
		var t := n as Drone
		if t == null or not t.alive:
			continue
		var cp := Geometry3D.get_closest_point_to_segment(t.global_position, prev, nxt)
		var reach := t.radius + (14.0 if kind == "missile" else 0.0)
		if cp.distance_to(t.global_position) < reach:
			t.take_damage(60.0 if kind == "missile" else 10.0)
			Fx.explode(get_tree(), cp, 22.0 if kind == "missile" else 5.0)
			queue_free()
			return
	var h := maxf(terrain.height_at(nxt.x, nxt.z), 0.0)
	if nxt.y < h:
		if kind == "missile":
			Fx.explode(get_tree(), nxt, 18.0)
		queue_free()

func _home(dt: float) -> void:
	var spd := minf(vel.length() + 260.0 * dt, 480.0)
	var dir := vel.normalized()
	if target != null and is_instance_valid(target):
		var t := target as Drone
		if t != null and t.alive:
			var want := (t.global_position - global_position).normalized()
			dir = dir.slerp(want, clampf(2.6 * dt, 0.0, 1.0)).normalized()
	vel = dir * spd
	if absf(dir.y) < 0.98:
		look_at(global_position + dir, Vector3.UP)
