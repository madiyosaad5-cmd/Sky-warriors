class_name Jet
extends Node3D
# Arcade flight model: pitch/roll/yaw rates, speed from throttle, gravity on climb/dive,
# stall below STALL speed, auto-level when the stick is released.

const MAX_SPEED := 230.0
const CRUISE_MIN := 70.0
const STALL := 60.0
const MAP_LIMIT := 5600.0
const START := Vector3(0.0, 1500.0, 2800.0)

var terrain: TerrainMap
var speed := 150.0
var throttle := 0.6
var brake := false
var stick := Vector2.ZERO   # x = roll (right +), y = screen-down +
var invert_y := false
var fire_held := false
var alive := true
var cockpit := false
var kills := 0
var ammo_gun := 1000.0
var ammo_missile := 6
var flares := 12
var lock_target: Node3D
var lock_time := 0.0
var locked := false
var agl := 9999.0
var out_of_bounds := false

var chase_cam: Camera3D
var cockpit_cam: Camera3D
var model: Node3D
var engine: MeshInstance3D
var engine_mat: StandardMaterial3D
var shake := 0.0
var cam_up := Vector3.UP
var gun_cd := 0.0
var missile_cd := 0.0
var flare_cd := 0.0
var respawn_t := 0.0
var missile_regen := 0.0
var flare_regen := 0.0
var side_flip := false

func _ready() -> void:
	add_to_group("jet")
	model = Node3D.new()
	add_child(model)
	_build_model()
	chase_cam = Camera3D.new()
	chase_cam.top_level = true
	chase_cam.near = 1.0
	chase_cam.far = 25000.0
	add_child(chase_cam)
	cockpit_cam = Camera3D.new()
	cockpit_cam.position = Vector3(0.0, 1.0, -2.2)
	cockpit_cam.near = 0.3
	cockpit_cam.far = 25000.0
	add_child(cockpit_cam)
	global_position = START
	chase_cam.global_position = START + Vector3(0.0, 6.0, 14.0)
	chase_cam.make_current()

# ---------- model ----------
func _box(size: Vector3, pos: Vector3, rot: Vector3, mat: Material) -> void:
	var b := BoxMesh.new()
	b.size = size
	var m := MeshInstance3D.new()
	m.mesh = b
	m.material_override = mat
	m.position = pos
	m.rotation_degrees = rot
	model.add_child(m)

func _build_model() -> void:
	var gray := StandardMaterial3D.new()
	gray.albedo_color = Color(0.5, 0.54, 0.6)
	gray.metallic = 0.6
	gray.roughness = 0.4
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.1, 0.3, 0.5)
	glass.metallic = 0.8
	glass.roughness = 0.1
	var cap := CapsuleMesh.new()
	cap.radius = 0.9
	cap.height = 12.0
	var fus := MeshInstance3D.new()
	fus.mesh = cap
	fus.material_override = gray
	fus.rotation_degrees = Vector3(90, 0, 0)
	model.add_child(fus)
	_box(Vector3(6.0, 0.15, 4.0), Vector3(-3.6, -0.1, 1.5), Vector3(0, 25, 0), gray)
	_box(Vector3(6.0, 0.15, 4.0), Vector3(3.6, -0.1, 1.5), Vector3(0, -25, 0), gray)
	_box(Vector3(3.0, 0.12, 1.6), Vector3(-2.0, 0, 5.0), Vector3(0, 20, 0), gray)
	_box(Vector3(3.0, 0.12, 1.6), Vector3(2.0, 0, 5.0), Vector3(0, -20, 0), gray)
	_box(Vector3(0.15, 2.2, 2.0), Vector3(-0.9, 1.4, 4.5), Vector3.ZERO, gray)
	_box(Vector3(0.15, 2.2, 2.0), Vector3(0.9, 1.4, 4.5), Vector3.ZERO, gray)
	var sph := SphereMesh.new()
	sph.radius = 0.5
	sph.height = 1.0
	var can := MeshInstance3D.new()
	can.mesh = sph
	can.material_override = glass
	can.position = Vector3(0, 0.75, -1.8)
	can.scale = Vector3(0.8, 0.7, 2.2)
	model.add_child(can)
	engine_mat = StandardMaterial3D.new()
	engine_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	engine_mat.albedo_color = Color(1.0, 0.45, 0.1)
	var es := SphereMesh.new()
	es.radius = 0.55
	es.height = 1.1
	engine = MeshInstance3D.new()
	engine.mesh = es
	engine.material_override = engine_mat
	engine.position = Vector3(0, 0, 6.3)
	model.add_child(engine)

# ---------- main loop ----------
func _process(dt: float) -> void:
	shake = maxf(shake - dt * 1.6, 0.0)
	if not alive:
		respawn_t -= dt
		if respawn_t <= 0.0:
			_respawn()
		_update_camera(dt)
		return
	_fly(dt)
	_update_lock(dt)
	_weapons(dt)
	_update_camera(dt)

func _key(k: Key) -> bool:
	return Input.is_physical_key_pressed(k)

func _fly(dt: float) -> void:
	var s := stick
	s.x += float(_key(KEY_D)) - float(_key(KEY_A))
	s.y += float(_key(KEY_S)) - float(_key(KEY_W))
	s = s.limit_length(1.0)
	if _key(KEY_SHIFT):
		throttle = minf(throttle + dt * 0.6, 1.0)
	if _key(KEY_CTRL):
		throttle = maxf(throttle - dt * 0.6, 0.0)
	var airbrake := brake or _key(KEY_B)
	var pitch := s.y if invert_y else -s.y
	var yaw_cmd := float(_key(KEY_Q)) - float(_key(KEY_E)) - s.x * 0.25
	var b := global_transform.basis
	var auth := clampf(speed / (STALL * 1.8), 0.35, 1.0)
	var roll := s.x
	if absf(s.x) < 0.08:
		roll = clampf(b.x.y * (2.5 if s.length() < 0.1 else 0.8), -1.0, 1.0)
	b = b.rotated(b.x, pitch * 1.15 * auth * dt)
	b = b.rotated(b.z, -roll * 2.4 * dt)
	b = b.rotated(b.y, yaw_cmd * 0.5 * dt)
	var fwd := -b.z
	var tgt := lerpf(CRUISE_MIN, MAX_SPEED, throttle)
	var acc := 40.0
	if airbrake:
		tgt = STALL + 5.0
		acc = 80.0
	speed = move_toward(speed, tgt, acc * dt)
	speed = clampf(speed - fwd.y * 55.0 * dt, 25.0, MAX_SPEED * 1.3)
	var sink := 0.0
	if speed < STALL:
		var f := (STALL - speed) / STALL
		sink = f * 70.0
		var ax := fwd.cross(Vector3.DOWN)
		if ax.length() > 0.01:
			b = b.rotated(ax.normalized(), f * 0.9 * dt)
	global_transform.basis = b.orthonormalized()
	global_position += (fwd * speed + Vector3.DOWN * sink) * dt
	# keep inside the map
	var flat := Vector3(global_position.x, 0.0, global_position.z)
	out_of_bounds = flat.length() > MAP_LIMIT
	if out_of_bounds:
		var ff := Vector3(fwd.x, 0.0, fwd.z)
		if ff.length() > 0.05:
			var a := ff.normalized().signed_angle_to(-flat.normalized(), Vector3.UP)
			global_rotate(Vector3.UP, clampf(a, -1.0, 1.0) * 0.9 * dt)
	# ground / sea collision
	var gh := maxf(terrain.height_at(global_position.x, global_position.z), 0.0)
	agl = global_position.y - gh
	if agl < 4.0:
		_crash()
	# engine glow
	engine.scale = Vector3(1.0, 1.0, 0.6 + throttle * 1.8)
	engine_mat.albedo_color = Color(1.0, 0.4, 0.1).lerp(Color(1.0, 0.9, 0.5), throttle)

func _crash() -> void:
	alive = false
	respawn_t = 3.0
	model.visible = false
	fire_held = false
	Fx.explode(get_tree(), global_position, 40.0)
	Input.vibrate_handheld(300)

func _respawn() -> void:
	alive = true
	model.visible = not cockpit
	global_transform = Transform3D(Basis.IDENTITY, START)
	speed = 150.0
	throttle = 0.6
	ammo_gun = 1000.0
	ammo_missile = 6
	flares = 12
	lock_target = null
	lock_time = 0.0
	locked = false
	cam_up = Vector3.UP
	chase_cam.global_position = START + Vector3(0.0, 6.0, 14.0)

# ---------- targeting & weapons ----------
func _update_lock(dt: float) -> void:
	var fwd := -global_transform.basis.z
	var best: Node3D = null
	var best_ang := 0.35
	for n in get_tree().get_nodes_in_group("targets"):
		var t := n as Drone
		if t == null or not t.alive:
			continue
		var d := t.global_position - global_position
		if d.length() > 4000.0:
			continue
		var a := fwd.angle_to(d)
		if a < best_ang:
			best_ang = a
			best = t
	if best != null and best == lock_target:
		lock_time += dt
	else:
		lock_target = best
		lock_time = 0.0
	locked = best != null and lock_time >= 1.0

func _weapons(dt: float) -> void:
	gun_cd -= dt
	missile_cd -= dt
	flare_cd -= dt
	var firing := fire_held or _key(KEY_SPACE)
	if firing and gun_cd <= 0.0 and ammo_gun >= 1.0:
		gun_cd = 0.07
		ammo_gun -= 1.0
		side_flip = not side_flip
		var b := global_transform.basis
		var o := b.x * (2.0 if side_flip else -2.0)
		_spawn("bullet", global_position - b.z * 8.0 + o, -b.z * (speed + 800.0))
	if not firing:
		ammo_gun = minf(ammo_gun + 50.0 * dt, 1000.0)
	missile_regen += dt
	if missile_regen >= 8.0:
		missile_regen = 0.0
		ammo_missile = mini(ammo_missile + 1, 6)
	flare_regen += dt
	if flare_regen >= 4.0:
		flare_regen = 0.0
		flares = mini(flares + 1, 12)

func _spawn(kind: String, pos: Vector3, vel: Vector3, tgt: Node3D = null) -> void:
	var p := Projectile.new()
	p.kind = kind
	p.vel = vel
	p.target = tgt
	get_parent().add_child(p)
	p.global_position = pos

func fire_missile() -> void:
	if not alive or ammo_missile <= 0 or missile_cd > 0.0:
		return
	ammo_missile -= 1
	missile_cd = 0.8
	var b := global_transform.basis
	var side := -1.0 if ammo_missile % 2 == 0 else 1.0
	_spawn("missile", global_position + b.x * side * 2.5 - b.y * 0.6, -b.z * (speed + 40.0), lock_target if locked else null)
	Input.vibrate_handheld(40)

func drop_flare() -> void:
	if not alive or flares <= 0 or flare_cd > 0.0:
		return
	flares -= 1
	flare_cd = 0.25
	var b := global_transform.basis
	for i in 2:
		var side := -30.0 if i == 0 else 30.0
		_spawn("flare", global_position + b.z * 6.0, -b.z * speed * 0.5 + b.x * side + Vector3.DOWN * 10.0)

func add_kill() -> void:
	kills += 1

# ---------- camera ----------
func current_cam() -> Camera3D:
	return cockpit_cam if cockpit else chase_cam

func toggle_cam() -> void:
	cockpit = not cockpit
	model.visible = alive and not cockpit
	current_cam().make_current()

func on_explosion(pos: Vector3, size: float) -> void:
	var d := global_position.distance_to(pos)
	shake = maxf(shake, clampf(size * 6.0 / maxf(d, 40.0), 0.0, 1.0))
	if shake > 0.5:
		Input.vibrate_handheld(80)

func _update_camera(dt: float) -> void:
	var b := global_transform.basis
	if not cockpit:
		var want := global_position + b.z * 14.0 + b.y * 5.0
		chase_cam.global_position = chase_cam.global_position.lerp(want, 1.0 - exp(-12.0 * dt))
		cam_up = cam_up.lerp(b.y, 1.0 - exp(-3.0 * dt)).normalized()
		chase_cam.look_at(global_position - b.z * 40.0, cam_up)
		chase_cam.fov = lerpf(chase_cam.fov, 68.0 + speed / MAX_SPEED * 14.0, 0.05)
	var c := current_cam()
	c.h_offset = randf_range(-1.0, 1.0) * shake * 1.2
	c.v_offset = randf_range(-1.0, 1.0) * shake * 1.2
