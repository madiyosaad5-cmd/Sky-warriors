extends Node3D
# Builds the whole world in code: sky, terrain, ocean, clouds, jet, targets, HUD.

func _ready() -> void:
	randomize()
	_environment()
	var terrain := TerrainMap.new()
	add_child(terrain)
	_water()
	_clouds()
	var jet := Jet.new()
	jet.terrain = terrain
	add_child(jet)
	for i in 6:
		add_child(Drone.new())
	var layer := CanvasLayer.new()
	layer.layer = 10
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var ui := Hud.new()
	ui.jet = jet
	layer.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _environment() -> void:
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.22, 0.42, 0.8)
	sm.sky_horizon_color = Color(0.72, 0.83, 0.93)
	sm.ground_horizon_color = Color(0.72, 0.83, 0.93)
	sm.ground_bottom_color = Color(0.35, 0.45, 0.55)
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.83, 0.93)
	env.fog_density = 0.00012
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
	sun.light_energy = 1.3
	add_child(sun)

func _water() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(60000.0, 60000.0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.04, 0.24, 0.4)
	mat.metallic = 0.3
	mat.roughness = 0.25
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = mat
	add_child(mi)

func _clouds() -> void:
	var count := 360
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 10
	sm.rings = 5
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1, 1, 1, 0.82)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 1.0
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = sm
	mm.instance_count = count
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var idx := 0
	while idx < count:
		var c := Vector3(rng.randf_range(-7000, 7000), rng.randf_range(1100, 2400), rng.randf_range(-7000, 7000))
		for k in 5:
			if idx >= count:
				break
			var p := c + Vector3(rng.randf_range(-250, 250), rng.randf_range(-40, 40), rng.randf_range(-250, 250))
			var s := Vector3(rng.randf_range(120, 260), rng.randf_range(50, 90), rng.randf_range(120, 260))
			mm.set_instance_transform(idx, Transform3D(Basis.from_scale(s), p))
			idx += 1
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = mat
	add_child(mmi)
