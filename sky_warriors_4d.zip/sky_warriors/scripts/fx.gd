class_name Fx
extends RefCounted
# Simple explosion: fireball + flash + lingering smoke, plus camera shake via the "jet" group.

static func explode(tree: SceneTree, pos: Vector3, size: float) -> void:
	_blob(tree, pos, size, Color(1.0, 0.6, 0.15, 0.95), 0.6)
	_blob(tree, pos, size * 0.7, Color(1.0, 0.95, 0.6, 0.95), 0.3)
	_blob(tree, pos, size * 1.5, Color(0.12, 0.12, 0.12, 0.7), 2.2)
	tree.call_group("jet", "on_explosion", pos, size)

static func _blob(tree: SceneTree, pos: Vector3, size: float, col: Color, dur: float) -> void:
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 12
	sm.rings = 6
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = col
	var mi := MeshInstance3D.new()
	mi.mesh = sm
	mi.material_override = mat
	tree.current_scene.add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3.ONE * size * 0.2
	var t := mi.create_tween().set_parallel(true)
	t.tween_property(mi, "scale", Vector3.ONE * size, dur).set_ease(Tween.EASE_OUT)
	t.tween_property(mat, "albedo_color:a", 0.0, dur)
	t.chain().tween_callback(mi.queue_free)
