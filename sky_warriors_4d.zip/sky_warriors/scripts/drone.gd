class_name Drone
extends Node3D
# Target drone flying a circular patrol. Shoot it with guns or missiles; respawns after 5s.

var alive := true
var hp := 40.0
var radius := 10.0
var center := Vector3.ZERO
var orbit_r := 1000.0
var alt := 1000.0
var ang := 0.0
var dir := 1.0
var rate := 0.1
var respawn_t := 0.0

func _ready() -> void:
	add_to_group("targets")
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.8, 0.1, 0.1)
	mat.emission_enabled = true
	mat.emission = Color(0.9, 0.1, 0.05)
	mat.emission_energy_multiplier = 0.6
	_part(Vector3(3.0, 1.5, 14.0), Vector3.ZERO, mat)
	_part(Vector3(18.0, 0.4, 4.0), Vector3(0, 0, 2), mat)
	_part(Vector3(0.4, 3.0, 3.0), Vector3(0, 1.5, 6), mat)
	_randomize_orbit()
	_step(0.0)

func _part(size: Vector3, pos: Vector3, mat: Material) -> void:
	var b := BoxMesh.new()
	b.size = size
	var m := MeshInstance3D.new()
	m.mesh = b
	m.material_override = mat
	m.position = pos
	add_child(m)

func _randomize_orbit() -> void:
	center = Vector3(randf_range(-1500, 1500), 0.0, randf_range(-1500, 1500))
	orbit_r = randf_range(500.0, 1400.0)
	alt = randf_range(950.0, 1500.0)
	ang = randf_range(0.0, TAU)
	dir = 1.0 if randf() < 0.5 else -1.0
	rate = randf_range(90.0, 150.0) / orbit_r

func _step(dt: float) -> void:
	ang += dir * rate * dt
	var p := center + Vector3(cos(ang) * orbit_r, 0.0, sin(ang) * orbit_r)
	p.y = alt + sin(ang * 4.0) * 80.0
	var tangent := Vector3(-sin(ang), 0.0, cos(ang)) * dir
	global_position = p
	look_at(p + tangent, Vector3.UP)

func _process(dt: float) -> void:
	if not alive:
		respawn_t -= dt
		if respawn_t <= 0.0:
			alive = true
			hp = 40.0
			visible = true
			_randomize_orbit()
			_step(0.0)
		return
	_step(dt)

func take_damage(d: float) -> void:
	hp -= d
	if hp > 0.0 or not alive:
		return
	alive = false
	visible = false
	respawn_t = 5.0
	Fx.explode(get_tree(), global_position, 45.0)
	get_tree().call_group("jet", "add_kill")
