# Sky Warriors 4D - Prototype (Stage 1-2 + basic weapons)

Open `project.godot` in Godot 4.2+ and press F5.

Desktop test keys: WASD pitch/roll, Q/E yaw, Shift/Ctrl throttle, Space guns,
M missile, F flare, B brake, C camera, I invert Y, Esc pause. Mouse clicks act as touch.

Android: install export templates, set Android SDK + JDK in Editor Settings > Export > Android,
then Project > Export > Add > Android > Export APK (or one-click deploy with USB debugging).
Project is set to landscape + GL Compatibility renderer for low-end phones.
